package com.main;

import com.child.PersonalLoan;
import com.parent.Loan;

public class TestApp {

	public static void main(String[] args) {
		
		Loan loan=new PersonalLoan();
		
		// A constructor can have same name as class name.
		// It is mostly used for initialization purpose of instance variables of class.
		// A class can have any number of constructors.
		// A constructor doesn't have any return type, not even void.
		// In a constructor, we can give super() or this() in first line.
		// super() to invoke an parent class constructor
		// this() to invoke an same class constructor
		// A static constructor can not be a parameterized constructor.
		// Within a class, you can create one static constructor only.
		

	}

}
