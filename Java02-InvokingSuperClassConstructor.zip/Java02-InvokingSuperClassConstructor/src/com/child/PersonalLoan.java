package com.child;

import com.parent.Loan;

public class PersonalLoan extends Loan {

	public PersonalLoan() {
		super();
		System.out.println("PesonalLoan (Child class) object is created");
	}
	
	

}
