package in.crud.datatransferobject;

import java.io.Serializable;

public class Student implements Serializable {
	private static final long serialVersionUID=1L;
	private Integer sid;
	private String sname;
	private Integer sage;
	private String saddress;
	public void setSid(Integer sid) {
		this.sid = sid;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public void setSage(Integer sage) {
		this.sage = sage;
	}
	public void setSaddress(String saddress) {
		this.saddress = saddress;
	}
	public Integer getSid() {
		return sid;
	}
	public String getSname() {
		return sname;
	}
	public Integer getSage() {
		return sage;
	}
	public String getSaddress() {
		return saddress;
	}
	@Override
	public String toString() {
		return "Student [sid=" + sid + ", sname=" + sname + ", sage=" + sage + ", saddress=" + saddress + "]";
	}
	
	
}
