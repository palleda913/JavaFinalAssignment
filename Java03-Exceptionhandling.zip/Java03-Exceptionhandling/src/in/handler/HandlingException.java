package in.handler;

public class HandlingException {
	
	public static void checkPositiveOrNegative(Integer num) {
		
		if(num<0)
			throw new RuntimeException("Negative number..!");
		else
			System.out.println("Entered number is ::"+num);
		
	}

}
