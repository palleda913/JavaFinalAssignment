package in.ineuron.sevice;

import java.util.List;

import in.ineuron.model.Order;
import in.ineuron.model.User;

public interface IOrderService {
	
	public List<Order> getAllOrders();
	public List<Order> getOrderByUser(User user);
	public String saveOrder(Order order);

}
