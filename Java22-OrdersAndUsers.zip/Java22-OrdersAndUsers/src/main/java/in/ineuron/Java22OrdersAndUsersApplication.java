package in.ineuron;

import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import in.ineuron.model.User;
import in.ineuron.sevice.OrderServiceImpl;

@SpringBootApplication
public class Java22OrdersAndUsersApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext run = SpringApplication.run(Java22OrdersAndUsersApplication.class, args);
		
		OrderServiceImpl orderService = run.getBean(OrderServiceImpl.class);
		Scanner scan =new Scanner(System.in);;
	
//				System.out.println("Enter user id");
//				int id = scan.nextInt();
//				User user1 =new User();
//				user1.setId(id);
				orderService.getAllOrders().forEach(System.out::println);
				//orderService.getOrderByUser(user1).forEach(System.out::println);
			
		scan.close();
	}

}
