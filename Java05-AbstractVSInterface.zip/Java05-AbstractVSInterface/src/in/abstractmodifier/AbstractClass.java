package in.abstractmodifier;

public abstract class AbstractClass {

	int a=10;
	public static final int b=20;
	
    //We can place constructor inside abstract class
	public AbstractClass(int a) {
		super();
		this.a = a;
	}

	public void m1() {
		
		System.out.println("We can give both concrete methods and abstract methods");
	}
	
	//If abstract method ,must need abstract modifier
	public abstract void m2();
	
	
	//To give the implementation of abstract class we use 'extends' keyword
	//it does not supports multiple inheritance
	//It can implement one interface only

}
