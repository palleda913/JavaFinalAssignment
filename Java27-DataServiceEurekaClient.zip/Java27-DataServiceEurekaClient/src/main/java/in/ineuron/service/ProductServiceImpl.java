package in.ineuron.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.ineuron.exception.ProductNotFoundException;
import in.ineuron.model.Product;
import in.ineuron.repo.IProductRepo;

@Service
public class ProductServiceImpl {
	
	@Autowired
	private IProductRepo repo;
	
	public List<Product> getAllProduct() {
		return (List)repo.findAll();
	}

	
	public Product getProductById(Integer id)throws ProductNotFoundException  {
		Optional<Product> optional = repo.findById(id);
		if(optional.isPresent()) {
			return optional.get();
		}else {
		   throw new ProductNotFoundException("Product not found for id::"+id);
		}
	}

}
