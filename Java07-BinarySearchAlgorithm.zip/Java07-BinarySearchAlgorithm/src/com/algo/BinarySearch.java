package com.algo;

import java.util.Scanner;

public class BinarySearch {
	
	public static int binarySearch(int a[],int start ,int end,int key)
	{
		while(start<=end) {
			int mid=(start+end)/2;
			
			if(key<a[mid]) {
				end=mid-1;
				
			}else if(key>a[mid]) {
				start=mid+1;
				
			}else if(key==a[mid]){
				return mid;
			}	
		}
		return -1;
		
	}
	public static void main(String[] args) {
		int arr[] = {2, 5, 8, 12, 16, 23, 38, 56, 72, 91};
		
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the key value to found in an sorted array");
        int target=scan.nextInt();
		
		int value = binarySearch(arr,0,arr.length-1, target);

		if(value==-1)
			System.out.println("The value not found in an array");
		else
			System.out.println("The Value found at index  ::"+value);
	}

}
