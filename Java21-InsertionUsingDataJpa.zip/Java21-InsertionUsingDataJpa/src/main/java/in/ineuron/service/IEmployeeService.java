package in.ineuron.service;

import in.ineuron.model.Employee;

public interface IEmployeeService {
	
	public String registerEmployee(Employee employee);

}
