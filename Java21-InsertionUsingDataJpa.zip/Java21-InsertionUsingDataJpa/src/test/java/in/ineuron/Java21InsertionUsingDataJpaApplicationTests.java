package in.ineuron;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Java21InsertionUsingDataJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
