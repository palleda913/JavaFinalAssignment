package in.spartan.repo;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import in.spartan.model.Register;

public interface IRegisterRepo extends CrudRepository<Register, Integer> {
	
	@Query("select count(*) from Register where email=:email and password=:password")
	public Integer validateUser(String email,String password);

}
