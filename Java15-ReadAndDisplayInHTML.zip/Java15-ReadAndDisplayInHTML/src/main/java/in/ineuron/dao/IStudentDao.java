package in.ineuron.dao;

import java.util.List;

import in.ineuron.dto.Student;

public interface IStudentDao {
	
	public List<Student> searchStudent();

}
