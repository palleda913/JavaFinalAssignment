package com.main;

import java.util.Scanner;

import com.shapes.Circle;
import com.shapes.IShape;
import com.shapes.Rectangle;
import com.shapes.Square;
import com.shapes.Triangle;

public class TestApp {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		boolean flag=true;
		IShape shape=null;
		
		while(flag)
		{
			System.out.println();
			System.out.println();
			System.out.println();
			System.out.println(".............CALCULATING AREA AND PERIMETER FOR BELOW SHAPES.................... ");
			System.out.println();
			System.out.println("1. Circle");
			System.out.println("2. Rectangle");
			System.out.println("3. Square");
			System.out.println("4. Triangle");
			System.out.println("5. Exit");
			System.out.println();
			System.out.println("ENETR YOUR OPTION");
			int choice=scan.nextInt();
			if(choice==1)
			{
				System.out.println("Enter radius..");
				double radius = scan.nextDouble();
				shape=new Circle(radius);
				
				System.out.println("Area of Circle is ::  "+shape.calculateArea());
				System.out.println("Perimeter of Circle is  ::  "+shape.calculatePerimeter());
				
			}
			else if(choice==2)
			{
				System.out.println("Enter Length..");
				double length = scan.nextDouble();
				System.out.println("Enter Breadth..");
				double breadth = scan.nextDouble();
				shape=new Rectangle(length,breadth);
				
				System.out.println("Area of Rectangle is :: "+shape.calculateArea());
				System.out.println("Perimeter of Rectangle  is  :: "+shape.calculatePerimeter());

			}
			else if(choice==3)
			{
				System.out.println("Enter Side length..");
				double side = scan.nextDouble();
				shape=new Square(side);
				
				System.out.println("Area of Square is ::  "+shape.calculateArea());
				System.out.println("Perimeter of Square is  ::  "+shape.calculatePerimeter());
			}
			else if(choice==4)
			{
				System.out.println("Enter Base length..");
				double base = scan.nextDouble();
				System.out.println("Enter Height ..");
				double height = scan.nextDouble();
				System.out.println("Enter Hypotenuse length ..");
				double hypoSide = scan.nextDouble();
				shape=new Triangle(base,height,hypoSide);
				
				System.out.println("Area of Triangle is :: "+shape.calculateArea());
				System.out.println("Perimeter of Triangle  is  :: "+shape.calculatePerimeter());

			}
			else
			{
				flag=false;
				System.exit(0);
			}
				

	}
	}

}
