package in.spartan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Java24BuildRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Java24BuildRestApiApplication.class, args);
	}

}
