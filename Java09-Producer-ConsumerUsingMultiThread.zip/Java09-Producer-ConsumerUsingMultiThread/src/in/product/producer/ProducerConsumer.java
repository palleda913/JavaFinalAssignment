package in.product.producer;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class ProducerConsumer {
		
	LinkedList<Double> list = new LinkedList<>();
    
	 public void produce() throws InterruptedException
     {
		int capacity=10;
         for (int i=0;i<capacity;i++){
             synchronized (this)
             {
                 // producer thread waits while list is full
                if(list.size()==capacity)
                	notify();

                 Double ran=Math.random();
                 System.out.println(ran);
                 list.add(ran);

             }
         }
     }
	 
	 public void consume() throws InterruptedException
     {
         
             synchronized (this)
             {
            	 Double sum=0.0;
            	 
                 // consumer thread waits while list generates a random number
                 while (list.size() == 0)
                     wait();

                 Iterator itr=list.iterator(); 
				 while(itr.hasNext()) {
					 sum=sum+ (Double)itr.next();
				 }

                System.out.println("Sum of Queue is::"+sum);
             }
         
     }

}
