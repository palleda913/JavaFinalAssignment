package in.ineuron.utility;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class UtilityClass {

	static
	{
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Driver class loaded Successfully");
		}
		catch(ClassNotFoundException cfe)
		{
			cfe.printStackTrace();
		}
		
	}
	public static Connection getConnect() throws SQLException, IOException
	{
		String location="F:\\JavaFinalAssignment\\Java17-ViewAndCreateBlogPosts\\src\\main\\java\\in\\ineuron\\properties\\dao.properties";
		FileInputStream fis=new FileInputStream(location);
		Properties p=new Properties();
		p.load(fis);
		Connection connection=DriverManager.getConnection(p.getProperty("url"),p.getProperty("user"),p.getProperty("password"));
		return connection;
	}
	public static void closeResources(Connection c,Statement s,ResultSet rs) throws SQLException
	{
		if(c!=null)
			c.close();
		if(s!=null)
			s.close();
		if(rs!=null)
			rs.close();
		System.out.println("All Resources closed");
	}
}
