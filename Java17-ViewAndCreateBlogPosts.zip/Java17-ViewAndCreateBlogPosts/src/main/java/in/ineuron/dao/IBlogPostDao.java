package in.ineuron.dao;

import java.util.List;
import in.ineuron.model.BlogPost;

public interface IBlogPostDao {
	
	public String createPost(BlogPost post);
	public List<BlogPost> viewPosts();

}
