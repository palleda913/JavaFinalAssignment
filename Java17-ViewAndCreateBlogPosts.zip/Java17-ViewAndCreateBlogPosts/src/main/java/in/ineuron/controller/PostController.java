package in.ineuron.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import in.ineuron.model.BlogPost;
import in.ineuron.service.IBlogPostService;
import in.ineuron.servicefactory.BlogPostServiceFactory;


@WebServlet("/test/*")
public class PostController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request, response);
	}
	
	protected void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		if(request.getRequestURI().endsWith("create")) {
			String title = request.getParameter("title");
			String description = request.getParameter("description");
			String content = request.getParameter("content");
			
			BlogPost post=new BlogPost();
			post.setTitle(title);
			post.setDescription(description);
			post.setContent(content);
			
			IBlogPostService blogPostService=BlogPostServiceFactory.getBlogPostService();
			String status = blogPostService.createPost(post);
			
			request.setAttribute("status",status);
			
			RequestDispatcher rd=request.getRequestDispatcher("../create-form.jsp");
			rd.forward(request, response);
			
		}else if(request.getRequestURI().endsWith("view")){
			
			IBlogPostService blogPostService=BlogPostServiceFactory.getBlogPostService();
			List<BlogPost> posts = blogPostService.viewPosts();
			
            request.setAttribute("posts",posts);
			
			RequestDispatcher rd=request.getRequestDispatcher("../display.jsp");
			rd.forward(request, response);
		}
	}

}
