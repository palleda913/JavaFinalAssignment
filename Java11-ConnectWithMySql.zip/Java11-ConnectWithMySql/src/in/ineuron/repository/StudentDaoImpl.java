package in.ineuron.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import in.ineuron.utility.UtilityClass;

public class StudentDaoImpl {
	
	public static void main(String[] args) {
		
		Connection connection=null;
		PreparedStatement ps=null;
		ResultSet result=null;
		try {
			Scanner scan=new Scanner(System.in);
			connection = UtilityClass.getConnect();
			
			System.out.println("Enter the Id to retrieve");
			int id = scan.nextInt();
			
			String selectQuery="select * from employee where empid=?";
			ps = connection.prepareStatement(selectQuery);
			ps.setInt(1, id);
			
			result = ps.executeQuery();
			
			 if(result.next())
			    {
			    	System.out.println("\tID\tNAME\tADDRESS\tSALARY");
			    	String name=result.getString(2);
			    	String address=result.getString(3);
			    	String salary=result.getString(4);
			    	System.out.print("\t"+id+"\t"+name+"\t"+address+"\t"+salary);
			    	System.out.println();
			    	System.out.println();
		
			    }
			    else
			    	System.out.println("Invalid id");
			 
		}catch(Exception e){
			e.getMessage();
		}finally {
			try {
				UtilityClass.closeResources(connection, ps, result);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
	}

}
