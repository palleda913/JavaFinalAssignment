package in.spartan.repo;

import org.springframework.data.repository.CrudRepository;
import in.spartan.model.Product;

public interface IProductRepo extends CrudRepository<Product,Integer>{

}
